// =======================================================================
// Proyecto Datalogger for IoT Curso 2022-2023
// Fecha: 29/11/2022 
// Autor: Pablo Villacorta, Rubén Serrano, Óscar Martín y Andrés Martín
// Asignatura: Taller de Proyectos I
// File: test.c  Rutinas de Test del GPS
// =======================================================================


